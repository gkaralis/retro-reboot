# boxbox

A framework that makes it easier to use the Box2d / Box2dweb physics engine in JavaScript.

## Learn about boxbox

http://incompl.github.com/boxbox

## box2dweb files are from

http://code.google.com/p/box2dweb/

## Demos, experiments, projects, etc.

 * [Don't look at me](http://dontlookatme.maryrosecook.com/)
 * [Platformer demo](http://incompl.github.io/boxbox/boxbox/demos/platformer/demo.html)
 * [Chain demo](http://incompl.github.io/boxbox/boxbox/demos/chain/chain.html)
 * [Box Fall](http://bama.ua.edu/~ardixon1/MAIN/Code/block_fall/play.html)
 * Add your project or demo here!

## Created at Bocoup

http://bocoup.com
